for(var i = 0; i < 109; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	BringToFront("u8");

	SetPanelState('u8', 'pd1u8','none','',500,'none','',500);

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u86'] = 'center';document.getElementById('u51_img').tabIndex = 0;
HookHover('u51', false);

u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', function(e) {

if (true) {

	SetPanelVisibility('u22','toggle','fade',500);

}
});
document.getElementById('u55_img').tabIndex = 0;

u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if (true) {

	SetPanelVisibility('u22','toggle','fade',500);

}
});
gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u31'] = 'center';document.getElementById('u107_img').tabIndex = 0;

u107.style.cursor = 'pointer';
$axure.eventManager.click('u107', function(e) {

if (true) {

	self.location.href='#';

}
});
document.getElementById('u32_img').tabIndex = 0;
HookClick('u32', false);

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	SetPanelVisibility('u22','toggle','fade',500);

}
});
gv_vAlignTable['u62'] = 'center';document.getElementById('u53_img').tabIndex = 0;
HookClick('u53', false);

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	SetPanelVisibility('u22','toggle','fade',500);

}
});
gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u7'] = 'top';document.getElementById('u30_img').tabIndex = 0;
HookHover('u30', false);

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	SetPanelVisibility('u22','toggle','fade',500);

}
});
gv_vAlignTable['u60'] = 'center';document.getElementById('u34_img').tabIndex = 0;

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	SetPanelVisibility('u22','toggle','fade',500);

}
});
gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u108'] = 'center';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	BringToFront("u22");

	SetPanelVisibility('u22','toggle','fade',500);

	SetPanelState('u8', 'pd0u8','none','',500,'none','',500);

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u90'] = 'center';gv_vAlignTable['u84'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u106'] = 'center';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u72'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	SetPanelState('u8', 'pd0u8','none','',500,'none','',500);

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u74'] = 'center';document.getElementById('u59_img').tabIndex = 0;

u59.style.cursor = 'pointer';
$axure.eventManager.click('u59', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u80'] = 'center';