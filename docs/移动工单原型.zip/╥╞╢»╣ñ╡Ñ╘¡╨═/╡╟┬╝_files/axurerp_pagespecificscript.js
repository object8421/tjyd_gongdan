for(var i = 0; i < 21; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u7'] = 'top';