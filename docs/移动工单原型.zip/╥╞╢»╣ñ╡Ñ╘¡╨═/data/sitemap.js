﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h),_(c,i,e,f,g,j,k,[_(c,l,e,f,g,m,k,[_(c,n,e,f,g,o),_(c,p,e,f,g,q),_(c,r,e,f,g,s),_(c,t,e,f,g,u),_(c,v,e,f,g,w),_(c,x,e,f,g,y),_(c,z,e,f,g,A),_(c,B,e,f,g,C)]),_(c,D,e,f,g,E),_(c,F,e,f,g,G),_(c,H,e,f,g,I),_(c,J,e,f,g,K)]),_(c,L,e,f,g,M),_(c,N,e,f,g,O),_(c,P,e,f,g,Q),_(c,R,e,f,g,S)]);}; 
var b="rootNodes",c="pageName",d="登录",e="type",f="Wireframe",g="url",h="登录.html",i="资源管理员",j="资源管理员.html",k="children",l="工单管理",m="工单管理.html",n="变更-资源待配置",o="变更-资源待配置.html",p="变更(做网站)-80待配置",q="变更_做网站_-80待配置.html",r="开通-资源待配置",s="开通-资源待配置.html",t="开通(做网站)-80待配置",u="开通_做网站_-80待配置.html",v="测试-资源待配置",w="测试-资源待配置.html",x="暂停-资源待暂停",y="暂停-资源待暂停.html",z="恢复-资源待恢复",A="恢复-资源待恢复.html",B="关闭-资源待关闭",C="关闭-资源待关闭.html",D="客户管理-资",E="客户管理-资.html",F="客户详情",G="客户详情.html",H="资源概况",I="资源概况.html",J="工单列表",K="工单列表.html",L="角色管理员",M="角色管理员.html",N="商务专员",O="商务专员.html",P="退单",Q="退单.html",R="新页面 1",S="新页面_1.html";
return _creator();
})();
